var GUI = (function (e) {
    function t(t) {
        for (var o, i, s = t[0], c = t[1], d = t[2], u = 0, p = []; u < s.length; u++) (i = s[u]), Object.prototype.hasOwnProperty.call(r, i) && r[i] && p.push(r[i][0]), (r[i] = 0);
        for (o in c) Object.prototype.hasOwnProperty.call(c, o) && (e[o] = c[o]);
        for (l && l(t); p.length; ) p.shift()();
        return a.push.apply(a, d || []), n();
    }
    function n() {
        for (var e, t = 0; t < a.length; t++) {
            for (var n = a[t], o = !0, s = 1; s < n.length; s++) {
                var c = n[s];
                0 !== r[c] && (o = !1);
            }
            o && (a.splice(t--, 1), (e = i((i.s = n[0]))));
        }
        return e;
    }
    var o = {},
        r = { 75: 0 },
        a = [];
    function i(t) {
        if (o[t]) return o[t].exports;
        var n = (o[t] = { i: t, l: !1, exports: {} });
        return e[t].call(n.exports, n, n.exports, i), (n.l = !0), n.exports;
    }
    (i.e = function (e) {
        var t = [],
            n = r[e];
        if (0 !== n)
            if (n) t.push(n[2]);
            else {
                var o = new Promise(function (t, o) {
                    n = r[e] = [t, o];
                });
                t.push((n[2] = o));
                var a,
                    s = document.createElement("script");
                (s.charset = "utf-8"),
                    (s.timeout = 120),
                    i.nc && s.setAttribute("nonce", i.nc),
                    (s.src = (function (e) {
                        i.p = "";
                        return (
                            i.p +
                            "https://cdn.jsdelivr.net/gh/jackb0back/turbowarp-self-host@main/js/" +
                            ({
                                4: "addon-default-entry",
                                5: "addon-entry-2d-color-picker",
                                6: "addon-entry-better-img-uploads",
                                7: "addon-entry-block-count",
                                8: "addon-entry-block-palette-icons",
                                9: "addon-entry-blocks2image",
                                10: "addon-entry-cat-blocks",
                                11: "addon-entry-clones",
                                12: "addon-entry-columns",
                                13: "addon-entry-custom-block-shape",
                                14: "addon-entry-custom-block-text",
                                15: "addon-entry-custom-zoom",
                                16: "addon-entry-data-category-tweaks-v2",
                                17: "addon-entry-debugger",
                                18: "addon-entry-default-costume-editor-color",
                                19: "addon-entry-disable-paste-offset",
                                20: "addon-entry-disable-stage-drag-select",
                                21: "addon-entry-editor-buttons-reverse-order",
                                22: "addon-entry-editor-colored-context-menus",
                                23: "addon-entry-editor-extra-keys",
                                24: "addon-entry-editor-sounds",
                                25: "addon-entry-editor-stage-left",
                                26: "addon-entry-editor-stepping",
                                27: "addon-entry-editor-theme3",
                                28: "addon-entry-fullscreen",
                                29: "addon-entry-gamepad",
                                30: "addon-entry-hide-delete-button",
                                31: "addon-entry-hide-flyout",
                                32: "addon-entry-hide-new-variables",
                                33: "addon-entry-hide-stage",
                                34: "addon-entry-initialise-sprite-position",
                                35: "addon-entry-load-extensions",
                                36: "addon-entry-mediarecorder",
                                37: "addon-entry-mouse-pos",
                                38: "addon-entry-no-script-bumping",
                                39: "addon-entry-number-pad",
                                40: "addon-entry-paint-by-default",
                                41: "addon-entry-paint-snap",
                                42: "addon-entry-remove-curved-stage-border",
                                43: "addon-entry-remove-sprite-confirm",
                                44: "addon-entry-script-snap",
                                45: "addon-entry-search-sprites",
                                46: "addon-entry-sprite-properties",
                                47: "addon-entry-swap-local-global",
                                48: "addon-entry-transparent-orphans",
                                49: "addon-entry-tw-disable-cloud-variables",
                                50: "addon-entry-tw-disable-compiler",
                                51: "addon-entry-tw-remove-backpack",
                                52: "addon-entry-tw-remove-feedback",
                                53: "addon-entry-tw-straighten-comments",
                                54: "addon-entry-variable-manager",
                                55: "addon-entry-vol-slider",
                                56: "addon-entry-zebra-striping",
                                57: "addon-l10n-de",
                                58: "addon-l10n-es",
                                59: "addon-l10n-fr",
                                60: "addon-l10n-hu",
                                61: "addon-l10n-it",
                                62: "addon-l10n-ja",
                                63: "addon-l10n-ko",
                                64: "addon-l10n-nl",
                                65: "addon-l10n-pl",
                                66: "addon-l10n-pt",
                                67: "addon-l10n-ro",
                                68: "addon-l10n-ru",
                                69: "addon-l10n-sl",
                                70: "addon-l10n-tr",
                                71: "addon-l10n-zh-tw",
                                73: "addons",
                                78: "iframe-extension-worker",
                                79: "library-backdrops",
                                80: "library-costumes",
                                81: "library-sounds",
                                82: "library-sprites",
                                84: "sb",
                            }[e] || e) +
                            "." +
                            {
                                4: "42dcaf7988e6ba3d6666",
                                5: "51523f446824842151ef",
                                6: "4e6e05fd3ea3dd8f5bfa",
                                7: "bd970d57b9f40f737523",
                                8: "7039694de39abf2a3e74",
                                9: "da50a8ce396bea92d4b4",
                                10: "3bd2030a1037b0f418eb",
                                11: "ec8e3183ae8dcb396a7e",
                                12: "494323bfd14dccd8e808",
                                13: "1f5475b16f17faa2df64",
                                14: "2281a76d8237a2919101",
                                15: "0fe579df8614853ce7ed",
                                16: "5b4b86358d58f1724158",
                                17: "317d3519b47e27e505d8",
                                18: "401a7cca8d524be38681",
                                19: "f9e141aaecee1a8288cf",
                                20: "f574f9cdf7e7dcdcc478",
                                21: "7740565b145bf9916e6d",
                                22: "b7d0c327852952d1da19",
                                23: "be1389e8fd3c3f5549bd",
                                24: "24b3c5bea6ed01640047",
                                25: "b62ac98c66274c310674",
                                26: "93dd42eab019fa2c37af",
                                27: "950956f07085216f887f",
                                28: "587e2db1772c44ff8800",
                                29: "3a358332ef045d35cc9f",
                                30: "eb8849cdc4b1b6d455d4",
                                31: "494465128c0dd29b7b57",
                                32: "ce129a58d7bdd84fa9fd",
                                33: "cd6881eb6bf7a7aa6dde",
                                34: "4da868ed87a1c6095879",
                                35: "013aacdfea5db508559a",
                                36: "b28c514a637fc131abbe",
                                37: "7f86bc6012a401cba355",
                                38: "f457924990f521eddf18",
                                39: "b80b04474ee5e072d15f",
                                40: "2f125918405b363ca854",
                                41: "d1a14146c031d3aa9a98",
                                42: "ae052e1bb00ac56569bc",
                                43: "0fd5af54f7f879f46a35",
                                44: "7f92042ce1dd0ce54260",
                                45: "08f2d2e45366be1d0c60",
                                46: "c306469136194ba786df",
                                47: "70c7abf2bfdf1f233f75",
                                48: "df82cdf49b041ef0ebc0",
                                49: "fa5fe7e20fb90ab3336b",
                                50: "41f50ee5bfd042ebd64d",
                                51: "0594b766509bfbc60982",
                                52: "6be5bbde580ebb3b81fa",
                                53: "ebed325fee21603ebe03",
                                54: "35a55aba7ec52bddffda",
                                55: "36987155692b3172a878",
                                56: "e52d57eed744e9f76a0e",
                                57: "c8a1eeb1563825d9f60d",
                                58: "7fc7fb398d4f1656e6cf",
                                59: "154a327915e33de81266",
                                60: "1fd7e8564874647ba05a",
                                61: "d1bda70ec4fec7593e65",
                                62: "e3daaa0142f668c4df1b",
                                63: "eade0dc6e4b782f0cdce",
                                64: "7aba06fcaf8fde1cdfb6",
                                65: "f05ebc3f2af1f4e423be",
                                66: "e25def6574b8c92f1b86",
                                67: "a69ecbc7bd7d87861db6",
                                68: "f9db56d1acc4203f755b",
                                69: "24e5200cf283fdb2344a",
                                70: "01e5751004270417f2b7",
                                71: "40e328e9c7f26a976cb7",
                                73: "fe9a8b42b384b607b056",
                                78: "2cd077cf22f1421f6cf3",
                                79: "2090b60c7f4c792346e8",
                                80: "6011ca51913f36c55e34",
                                81: "dbb24806bee9b8b16fff",
                                82: "3c4a98000634d526ac52",
                                84: "4fc991853965aaf426b7",
                            }[e] +
                            ".js"
                        );
                    })(e));
                var c = new Error();
                function removeTextBeforeHttps(inputString) {
                    const index = inputString.indexOf("https:");
                    
                    if (index !== -1) {
                      return inputString.substring(index);
                    } else {
                      return inputString;
                    }
                  }
                a = function (t) {
                    (s.onerror = s.onload = null), clearTimeout(d);
                    var n = r[e];
                    if (0 !== n) {
                        if (n) {
                            var o = t && ("load" === t.type ? "missing" : t.type),
                                a = t && t.target && t.target.src;
                                console.log(removeTextBeforeHttps(t.target.src));
                                t.target.src = removeTextBeforeHttps(t.target.src);
                            (c.message = "Loading chunk " + e + " failed.\n(" + o + ": " + a + ")"), (c.name = "ChunkLoadError"), (c.type = o), (c.request = a), n[1](c);
                        }
                        r[e] = void 0;
                    }
                };
                var d = setTimeout(function () {
                    a({ type: "timeout", target: s });
                }, 12e4);
                (s.onerror = s.onload = a), document.head.appendChild(s); console.log(s);
            }
        return Promise.all(t);
    }),
        (i.m = e),
        (i.c = o),
        (i.d = function (e, t, n) {
            i.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: n });
        }),
        (i.r = function (e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
        }),
        (i.t = function (e, t) {
            if ((1 & t && (e = i(e)), 8 & t)) return e;
            if (4 & t && "object" == typeof e && e && e.__esModule) return e;
            var n = Object.create(null);
            if ((i.r(n), Object.defineProperty(n, "default", { enumerable: !0, value: e }), 2 & t && "string" != typeof e))
                for (var o in e)
                    i.d(
                        n,
                        o,
                        function (t) {
                            return e[t];
                        }.bind(null, o)
                    );
            return n;
        }),
        (i.n = function (e) {
            var t =
                e && e.__esModule
                    ? function () {
                          return e.default;
                      }
                    : function () {
                          return e;
                      };
            return i.d(t, "a", t), t;
        }),
        (i.o = function (e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
        }),
        (i.p = "/"),
        (i.oe = function (e) {
            throw (console.error(e), e);
        });
    var s = (window.webpackJsonpGUI = window.webpackJsonpGUI || []),
        c = s.push.bind(s);
    (s.push = t), (s = s.slice());
    for (var d = 0; d < s.length; d++) t(s[d]);
    var l = c;
    return a.push([868, 0, 3, 1, 2]), n();
})({
    112: function (e, t) {
        var n = Array.isArray;
        e.exports = n;
    },
    115: function (e, t, n) {
        var o = n(247);
        "string" == typeof o && (o = [[e.i, o, ""]]);
        var r = { hmr: !0, transform: void 0, insertInto: void 0 };
        n(10)(o, r);
        o.locals && (e.exports = o.locals);
    },
    152: function (e, t, n) {
        (function (t) {
            var n = "object" == typeof t && t && t.Object === Object && t;
            e.exports = n;
        }.call(this, n(39)));
    },
    153: function (e, t, n) {
        e.exports = "https://turbowarp.org/static/assets/33b737193edfe1730f38112ad35a84b4.svg";
    },
    154: function (e, t, n) {
        e.exports = n.p + "sw.js";
    },
    155: function (e, t, n) {
        "use strict";
        var o = n(4),
            r = n.n(o),
            a = n(0),
            i = n.n(a),
            s = n(1),
            c = n.n(s),
            d = n(6),
            l = n(37),
            u = n(2),
            p = n(11),
            h = (n(156), n(157)),
            f = n(76),
            b = n(159),
            m = n(160),
            v = n(88),
            g = n(161),
            w = n(14);
        const y = ["canOpenPackager"];
        function _() {
            return (_ =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
                    }
                    return e;
                }).apply(this, arguments);
        }
        function j(e, t) {
            if (null == e) return {};
            var n,
                o,
                r = (function (e, t) {
                    if (null == e) return {};
                    var n,
                        o,
                        r = {},
                        a = Object.keys(e);
                    for (o = 0; o < a.length; o++) (n = a[o]), t.indexOf(n) >= 0 || (r[n] = e[n]);
                    return r;
                })(e, t);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                for (o = 0; o < a.length; o++) (n = a[o]), t.indexOf(n) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]));
            }
            return r;
        }
        const k = (e) =>
                new Promise((t, n) => {
                    const o = new FileReader();
                    (o.onload = () => t(o.result)), (o.onerror = () => n(new Error("Cannot read blob as array buffer"))), o.readAsArrayBuffer(e);
                }),
            x = function (e) {
                class t extends c.a.Component {
                    constructor(e) {
                        super(e), (this.handleClickPackager = this.handleClickPackager.bind(this)), (this.handleMessage = this.handleMessage.bind(this));
                    }
                    componentDidMount() {
                        window.addEventListener("message", this.handleMessage);
                    }
                    componentWillUnmount() {
                        window.removeEventListener("message", this.handleMessage);
                    }
                    handleClickPackager() {
                        this.props.canOpenPackager && window.open("".concat("https://packager.turbowarp.org", "/?import_from=").concat(location.origin));
                    }
                    handleMessage(e) {
                        if ("https://packager.turbowarp.org" !== e.origin) return;
                        if (!this.props.canOpenPackager) return;
                        "ready-for-import" === e.data.p4.type &&
                            (e.source.postMessage({ p4: { type: "start-import" } }, e.origin),
                            this.props.vm
                                .saveProjectSb3()
                                .then(k)
                                .then((t) => {
                                    const n = "".concat(this.props.reduxProjectTitle, ".sb3");
                                    e.source.postMessage({ p4: { type: "finish-import", data: t, name: n } }, e.origin, [t]);
                                })
                                .catch((t) => {
                                    w.default.error(t), e.source.postMessage({ p4: { type: "cancel-import" } }, e.origin);
                                }));
                    }
                    render() {
                        const t = this.props,
                            { canOpenPackager: n } = t,
                            o = j(t, y);
                        return c.a.createElement(e, _({ onClickPackager: this.handleClickPackager }, o));
                    }
                }
                t.propTypes = { canOpenPackager: i.a.bool, reduxProjectTitle: i.a.string, vm: i.a.shape({ saveProjectSb3: i.a.func }) };
                return Object(d.b)(
                    (e) => ({ canOpenPackager: Object(p.r)(e.scratchGui.projectState.loadingState), reduxProjectTitle: e.scratchGui.projectTitle, vm: e.scratchGui.vm }),
                    () => ({})
                )(t);
            };
        var E = n(22),
            O = n(5),
            P = n.n(O),
            C = n(12),
            S = n.n(C),
            T = n(162);
        const I = ["projectChanged", "onAutosavingStart", "onAutosavingFinish", "vm"];
        function A(e, t) {
            if (null == e) return {};
            var n,
                o,
                r = (function (e, t) {
                    if (null == e) return {};
                    var n,
                        o,
                        r = {},
                        a = Object.keys(e);
                    for (o = 0; o < a.length; o++) (n = a[o]), t.indexOf(n) >= 0 || (r[n] = e[n]);
                    return r;
                })(e, t);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                for (o = 0; o < a.length; o++) (n = a[o]), t.indexOf(n) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]));
            }
            return r;
        }
        let N = !1;
        var R = n(49);
        const F = history.replaceState;
        history.replaceState = function (...e) {
            try {
                return F.call(this, ...e);
            } catch (e) {
                w.default.error(e);
            }
        };
        const M = history.pushState;
        history.pushState = function (...e) {
            try {
                return M.call(this, ...e);
            } catch (e) {
                w.default.error(e);
            }
        };
        var L = n(170),
            D = n(171),
            U = n(65),
            B = n.n(U),
            H = n(115),
            W = n.n(H),
            G = n(90);
        const V = Object(u.d)({ tooltip: { id: "tw.input.tooltip", defaultMessage: "Copy and paste a Scratch project link here!" } });
        class K extends c.a.Component {
            constructor(e) {
                super(e), P()(this, ["handleKeyDown", "handleChange", "handleBlur", "handleFocus", "inputRef", "tooltipRef"]), (this.state = { projectId: this.props.projectId });
            }
            componentDidUpdate(e) {
                this.props.projectId !== e.projectId && (this.props.projectId === p.e ? (this.input.focus(), (this.input.selectionStart = this.input.value.length)) : this.input.blur(), this.setState({ projectId: this.props.projectId }));
            }
            extractProjectId(e) {
                const t = e.match(/\d+/);
                return t ? t[0] : null;
            }
            readProjectId(e) {
                return this.extractProjectId(e.target.value) || p.e;
            }
            handleKeyDown(e) {
                "Enter" === e.key && this.state.projectId && this.input.blur();
            }
            handleChange(e) {
                this.setState({ projectId: this.readProjectId(e) || p.e });
            }
            handleBlur() {
                this.state.projectId && this.state.projectId !== this.props.projectId && this.props.setProjectId(this.state.projectId), B.a.hide(this.tooltip);
            }
            handleFocus(e) {
                this.extractProjectId(e.target.value) && e.target.select(), B.a.show(this.tooltip);
            }
            inputRef(e) {
                this.input = e;
            }
            tooltipRef(e) {
                this.tooltip = e;
            }
            render() {
                const e = this.state.projectId === p.e ? "" : this.state.projectId || "";
                return c.a.createElement(
                    "div",
                    { ref: this.tooltipRef, "data-tip": this.props.intl.formatMessage(V.tooltip) },
                    c.a.createElement(B.a, { className: W.a.tooltip, effect: "solid" }),
                    c.a.createElement("input", {
                        ref: this.inputRef,
                        spellCheck: "false",
                        type: "text",
                        value: "".concat("https://scratch.mit.edu/projects/").concat(e),
                        className: W.a.input,
                        onKeyDown: this.handleKeyDown,
                        onChange: this.handleChange,
                        onBlur: this.handleBlur,
                        onFocus: this.handleFocus,
                    })
                );
            }
        }
        K.propTypes = { intl: u.f, projectId: i.a.string, setProjectId: i.a.func };
        var z = Object(u.e)(
                Object(d.b)(
                    (e) => ({ projectId: e.scratchGui.projectState.projectId }),
                    (e) => ({ setProjectId: (t) => Object(G.a)(e, t) })
                )(K)
            ),
            J = n(25),
            $ = n.n(J),
            q = function (e) {
                (this.studioId = e),
                    (this.offset = 0),
                    (this.ended = !1),
                    (this.loadingPage = !1),
                    (this.unusedPlaceholders = []),
                    (this.root = document.createElement("div")),
                    (this.root.className = $.a.studioviewRoot),
                    (this.projectList = document.createElement("div")),
                    (this.projectList.className = $.a.studioviewList),
                    this.root.appendChild(this.projectList),
                    "IntersectionObserver" in window
                        ? ((this.intersectionObserver = new IntersectionObserver(this.handleIntersection.bind(this), { root: this.projectList })),
                          (this.loadNextPageObserver = new IntersectionObserver(this.handleLoadNextPageIntersection.bind(this), { root: this.projectList })))
                        : ((this.intersectionObserver = null), (this.loadNextPageObserver = null)),
                    (this.messages = { AUTHOR_ATTRIBUTION: "", PROJECT_HOVER_TEXT: "", LOAD_ERROR: "" });
            };
        (q.prototype.addProject = function (e) {
            var t;
            this.unusedPlaceholders.length ? (t = this.unusedPlaceholders.shift()) : ((t = this.createPlaceholder()), this.projectList.appendChild(t)), this.placeholderToProject(t, e.id, e.title, e.author);
        }),
            (q.prototype.createLazyImage = function (e) {
                var t = document.createElement("img");
                return this.intersectionObserver ? (this.intersectionObserver.observe(t), (t.dataset.src = e)) : (t.src = e), t;
            }),
            (q.prototype.createPlaceholder = function () {
                var e = document.createElement("a");
                e.className = r()($.a.studioviewProject, $.a.studioviewPlaceholder);
                var t = document.createElement("div");
                t.className = $.a.studioviewThumbnail;
                var n = document.createElement("div");
                n.className = $.a.studioviewTitle;
                var o = document.createElement("div");
                return (o.className = $.a.studioviewAuthor), (e.thumbnailEl = t), (e.titleEl = n), (e.authorEl = o), e.appendChild(t), e.appendChild(n), e.appendChild(o), e;
            }),
            (q.prototype.placeholderToProject = function (e, t, n, o) {
                (e.className = r()($.a.studioviewProject, $.a.studioviewLoaded)),
                    (e.dataset.id = t),
                    (e.dataset.title = n),
                    (e.dataset.author = o),
                    (e.title = this.messages.PROJECT_HOVER_TEXT.replace("$author", o).replace("$title", n)),
                    (e.href = q.PROJECT_PAGE.replace("$id", t));
                var a = q.THUMBNAIL_SRC.replace("$id", t),
                    i = this.createLazyImage(a);
                return (
                    e.thumbnailEl.appendChild(i),
                    (e.titleEl.innerText = n),
                    (e.authorEl.innerText = this.messages.AUTHOR_ATTRIBUTION.replace("$author", o)),
                    e.addEventListener("click", this.handleClick.bind(this), !0),
                    e.addEventListener("keydown", this.handleKeyDown.bind(this), !0),
                    e
                );
            }),
            (q.prototype.addErrorElement = function () {
                var e = document.createElement("div");
                (e.innerText = this.messages.LOAD_ERROR), (e.className = $.a.studioviewError), this.projectList.appendChild(e);
            }),
            (q.prototype.handleLoadNextPageIntersection = function (e) {
                for (var t = 0; t < e.length; t++) {
                    e[t].isIntersecting && this.canLoadNext() && this.loadNextPage();
                }
            }),
            (q.prototype.clickProject = function (e) {
                for (; !e.classList.contains($.a.studioviewProject); ) e = e.parentNode;
                var t = e.dataset.id;
                this.onselect(t, e);
            }),
            (q.prototype.handleClick = function (e) {
                e.preventDefault(), this.clickProject(e.target);
            }),
            (q.prototype.handleKeyDown = function (e) {
                13 === e.keyCode && (e.preventDefault(), this.clickProject(e.target));
            }),
            (q.prototype.handleIntersection = function (e, t) {
                e.forEach(function (e) {
                    if (e.isIntersecting) {
                        var n = e.target;
                        (n.src = n.dataset.src), (n.dataset.src = ""), (n.className = ""), t.unobserve(n);
                    }
                });
            }),
            (q.prototype.canLoadNext = function () {
                return !this.loadingPage && !this.ended;
            }),
            (q.prototype.cleanupPlaceholders = function () {
                for (; this.unusedPlaceholders.length; ) {
                    var e = this.unusedPlaceholders.pop();
                    this.projectList.removeChild(e);
                }
            }),
            (q.prototype.addPlaceholders = function () {
                for (var e = 0; e < q.PLACEHOLDER_COUNT; e++) {
                    var t = this.createPlaceholder();
                    this.unusedPlaceholders.push(t), this.projectList.appendChild(t);
                }
            }),
            (q.prototype.shuffler = function (e) {
                return e;
            }),
            (q.prototype.loadNextPage = function () {
                if (this.loadingPage) throw new Error("Already loading the next page");
                if (this.ended) throw new Error("There are no more pages to load");
                0 === this.unusedPlaceholders.length && this.addPlaceholders(), this.loadNextPageObserver && this.loadNextPageObserver.disconnect(), this.root.setAttribute("loading", ""), (this.loadingPage = !0);
                var e = new XMLHttpRequest();
                (e.responseType = "json"),
                    (e.onload = function () {
                        var t = e.response;
                        if (Array.isArray(t)) {
                            for (var n = [], o = 0; o < t.length; o++) {
                                var r = t[o];
                                n.push({ id: r.id, title: r.title, author: r.username });
                            }
                            n = this.shuffler(n);
                            for (o = 0; o < n.length; o++) this.addProject(n[o]);
                            this.cleanupPlaceholders(),
                                40 === t.length ? this.loadNextPageObserver && this.loadNextPageObserver.observe(this.projectList.lastChild) : ((this.ended = !0), this.onend()),
                                (this.offset += n.length),
                                (this.loadingPage = !1),
                                this.root.removeAttribute("loading"),
                                this.onpageload();
                        } else e.onerror();
                    }.bind(this)),
                    (e.onerror = function () {
                        this.root.setAttribute("error", ""), this.cleanupPlaceholders(), this.addErrorElement(), (this.ended = !0);
                    }.bind(this));
                var t = q.STUDIO_API.replace("$id", this.studioId).replace("$offset", "" + this.offset);
                e.open("GET", t), e.send();
            }),
            (q.prototype.getURL = function () {
                return q.STUDIO_PAGE.replace("$id", this.studioId);
            }),
            (q.prototype.onselect = function (e, t) {}),
            (q.prototype.onpageload = function () {}),
            (q.prototype.onend = function () {}),
            (q.STUDIO_API = "https://trampoline.turbowarp.org/proxy/studios/$id/projects?offset=$offset"),
            (q.THUMBNAIL_SRC = "https://trampoline.turbowarp.org/thumbnails/$id?width=144&height=108"),
            (q.PROJECT_PAGE = "https://turbowarp.org/$id"),
            (q.STUDIO_PAGE = "https://scratch.mit.edu/studios/$id/"),
            (q.PLACEHOLDER_COUNT = 9);
        var Q = q;
        const X = Object(u.d)({
            authorAttribution: { id: "tw.studioview.authorAttribution", defaultMessage: "by {author}" },
            hoverText: { id: "tw.studioview.hoverText", defaultMessage: "{title} by {author}" },
            error: { id: "tw.studioview.error", defaultMessage: "There was an error loading the next page of projects." },
        });
        class Z extends c.a.Component {
            constructor(e) {
                super(e), P()(this, ["handleSelect", "ref"]);
            }
            componentDidMount() {
                (this.studioView = new Q(this.props.id)),
                    (this.studioView.messages.AUTHOR_ATTRIBUTION = this.props.intl.formatMessage(X.authorAttribution, { author: "$author" })),
                    (this.studioView.messages.PROJECT_HOVER_TEXT = this.props.intl.formatMessage(X.hoverText, { author: "$author", title: "$title" })),
                    (this.studioView.messages.LOAD_ERROR = this.props.intl.formatMessage(X.error)),
                    this.props.placeholder ? this.studioView.addPlaceholders() : this.studioView.loadNextPage(),
                    (this.studioView.onselect = this.handleSelect),
                    this.el.appendChild(this.studioView.root);
            }
            componentDidUpdate(e) {
                e.placeholder && !this.props.placeholder && this.studioView.loadNextPage();
            }
            handleSelect(e) {
                this.props.onSelect(e);
            }
            ref(e) {
                this.el = e;
            }
            render() {
                return c.a.createElement("div", { className: r()($.a.wrapper), ref: this.ref });
            }
        }
        Z.propTypes = { id: i.a.string.isRequired, intl: u.f.isRequired, placeholder: i.a.bool, onSelect: i.a.func.isRequired };
        var Y = Object(u.e)(Z),
            ee = n(46),
            te = n.n(ee);
        class ne extends c.a.Component {
            constructor(e) {
                super(e), P()(this, ["handleSelect", "handleOpenProjects"]), (this.state = { opened: !1, transition: !0 });
            }
            componentDidUpdate(e) {
                "0" === this.props.projectId && null === e.projectId && this.setState({ opened: !0, transition: !1 });
            }
            handleSelect(e) {
                this.props.setProjectId(e);
            }
            handleOpenProjects() {
                this.setState({ opened: !0 });
            }
            render() {
                const e = this.state.opened;
                return c.a.createElement(
                    "div",
                    { className: te.a.container },
                    c.a.createElement(
                        "div",
                        { className: r()(te.a.projects, { [te.a.opened]: e, [te.a.transition]: this.state.transition }) },
                        c.a.createElement(Y, { id: this.props.studio, onSelect: this.handleSelect, placeholder: !e }),
                        e
                            ? null
                            : c.a.createElement(
                                  "div",
                                  { className: te.a.openerContainer, onClick: this.handleOpenProjects },
                                  c.a.createElement("div", { className: te.a.openerContent }, c.a.createElement(u.a, { defaultMessage: "Click to view featured projects.", id: "tw.viewFeaturedProjects" }))
                              )
                    ),
                    c.a.createElement(
                        "div",
                        { className: te.a.footer },
                        c.a.createElement(
                            "a",
                            { target: "_blank", rel: "noopener noreferrer", href: "https://scratch.mit.edu/studios/".concat(this.props.studio, "/") },
                            c.a.createElement(u.a, { defaultMessage: "View studio on Scratch.", id: "tw.featuredProjectsStudio" })
                        )
                    )
                );
            }
        }
        ne.propTypes = { setProjectId: i.a.func, projectId: i.a.string, studio: i.a.string };
        var oe = Object(d.b)(
                (e) => ({ projectId: e.scratchGui.projectState.projectId }),
                (e) => ({ setProjectId: (t) => Object(G.a)(e, t) })
            )(ne),
            re = n(59),
            ae = n.n(re),
            ie = n(95),
            se = n.n(ie);
        const ce = (e) => {
                e = se()(e, /@([\w-]+)/, (e, t) => c.a.createElement("a", { href: "https://scratch.mit.edu/users/".concat(e, "/"), rel: "noreferrer", key: e + t }, "@".concat(e)));
                return (
                    (e = se()(e, /(https?:\/\/[\w\d_\-.]{1,256}(?:\/(?:\S*[\w:/#[\]@$&'()*+=])?)?(?![^?!,:;\w\s]\S))/g, (e, t) => c.a.createElement("a", { href: e, rel: "noreferrer", key: e + t }, e))),
                    (e = se()(e, /#([\w-]+)/g, (e, t) => c.a.createElement("a", { href: "https://scratch.mit.edu/search/projects?q=".concat(e), key: e + t }, "#".concat(e))))
                );
            },
            de = ({ instructions: e, credits: t, projectId: n }) =>
                "unshared" !== e &&
                "unshared" !== t &&
                c.a.createElement(
                    "div",
                    { className: ae.a.description },
                    c.a.createElement(
                        "div",
                        { className: ae.a.projectLink },
                        c.a.createElement("a", { href: "https://scratch.mit.edu/projects/".concat(n, "/"), target: "_blank", rel: "noreferrer" }, c.a.createElement(u.a, { defaultMessage: "View project on Scratch", id: "tw.viewOnScratch" }))
                    ),
                    e ? c.a.createElement("div", null, c.a.createElement("h2", { className: ae.a.header }, c.a.createElement(u.a, { defaultMessage: "Instructions", id: "tw.home.instructions" })), ce(e)) : null,
                    e && t ? c.a.createElement("div", { className: ae.a.divider }) : null,
                    t && c.a.createElement("div", null, c.a.createElement("h2", { className: ae.a.header }, c.a.createElement(u.a, { defaultMessage: "Notes and Credits", id: "tw.home.credit" })), ce(t))
                );
        de.propTypes = { instructions: i.a.string, credits: i.a.string, projectId: i.a.string };
        var le = de,
            ue = n(172),
            pe = n(168),
            he = n(153),
            fe = n.n(he),
            be = n(96),
            me = n.n(be);
        var ve = () =>
                c.a.createElement(
                    "div",
                    { className: me.a.badge },
                    c.a.createElement("div", { className: me.a.icon }, c.a.createElement("img", { src: fe.a, alt: "Cloud", width: "32", height: "32" })),
                    c.a.createElement(
                        "div",
                        { className: me.a.text },
                        c.a.createElement(u.a, {
                            defaultMessage: "This project uses cloud variables. TurboWarp uses its own cloud variable server independent of Scratch. Beware of impersonation as anyone can change their username to anything. {learnMore}",
                            id: "tw.cloudVariableBadge",
                            values: {
                                learnMore: c.a.createElement(
                                    "a",
                                    { href: "https://docs.turbowarp.org/cloud-variables", target: "_blank", rel: "noreferrer" },
                                    c.a.createElement(u.a, { defaultMessage: "Learn more.", id: "gui.alerts.cloudInfoLearnMore" })
                                ),
                            },
                        })
                    )
                ),
            ge = n(77),
            we = n(48),
            ye = n(154),
            _e = n.n(ye);
        let je = !1;
        const ke = () => {
            navigator.serviceWorker.register(_e.a).catch((e) => {
                w.default.error("sw error", e);
            });
        };
        var xe = n(169),
            Ee = n(17),
            Oe = n.n(Ee);
        const Pe = ["intl", "hasCloudVariables", "description", "isFullScreen", "isLoading", "isPlayerOnly", "isRtl", "onClickTheme", "projectId"];
        function Ce() {
            return (Ce =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
                    }
                    return e;
                }).apply(this, arguments);
        }
        function Se(e, t) {
            if (null == e) return {};
            var n,
                o,
                r = (function (e, t) {
                    if (null == e) return {};
                    var n,
                        o,
                        r = {},
                        a = Object.keys(e);
                    for (o = 0; o < a.length; o++) (n = a[o]), t.indexOf(n) >= 0 || (r[n] = e[n]);
                    return r;
                })(e, t);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                for (o = 0; o < a.length; o++) (n = a[o]), t.indexOf(n) >= 0 || (Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]));
            }
            return r;
        }
        if (window.parent !== window)
            throw (alert("This page is embedding TurboWarp in a way that is unsupported and will cease to function in the near future. Please read https://docs.turbowarp.org/embedding"), new Error("Invalid embed"));
        const Te = () => {
                window.open("".concat("/").concat("addons"));
            },
            Ie = Object(u.d)({ defaultTitle: { id: "tw.guiDefaultTitle", defaultMessage: "Run Scratch projects faster" } }),
            Ae = Object(l.d)(g.a, x)(D.a);
        we.a.reloadChannel &&
            we.a.reloadChannel.addEventListener("message", () => {
                location.reload();
            }),
            we.a.changeChannel &&
                we.a.changeChannel.addEventListener("message", (e) => {
                    R.a.setStoreWithVersionCheck(e.data);
                }),
            Object(xe.a)();
        const Ne = () =>
            c.a.createElement(
                "footer",
                { className: Oe.a.footer },
                c.a.createElement(
                    "div",
                    { className: Oe.a.footerContent },
                    c.a.createElement("div", { className: Oe.a.footerText }, c.a.createElement(u.a, { defaultMessage: "TurboWarp is not affiliated with Scratch, the Scratch Team, or the Scratch Foundation.", id: "tw.footer.disclaimer" })),
                    c.a.createElement(
                        "div",
                        { className: Oe.a.footerColumns },
                        c.a.createElement(
                            "div",
                            { className: Oe.a.footerSection },
                            c.a.createElement("a", { href: "credits.html" }, c.a.createElement(u.a, { defaultMessage: "Credits", id: "tw.footer.credits" })),
                            c.a.createElement("a", { href: "https://github.com/sponsors/GarboMuffin" }, c.a.createElement(u.a, { defaultMessage: "Donate", id: "tw.footer.donate" }))
                        ),
                        c.a.createElement(
                            "div",
                            { className: Oe.a.footerSection },
                            c.a.createElement("a", { href: "https://desktop.turbowarp.org/" }, "TurboWarp Desktop"),
                            c.a.createElement("a", { href: "https://packager.turbowarp.org/" }, "TurboWarp Packager"),
                            c.a.createElement("a", { href: "https://docs.turbowarp.org/embedding" }, c.a.createElement(u.a, { defaultMessage: "Embedding", id: "tw.footer.embed" })),
                            c.a.createElement("a", { href: "https://docs.turbowarp.org/url-parameters" }, c.a.createElement(u.a, { defaultMessage: "URL Parameters", id: "tw.footer.parameters" })),
                            c.a.createElement("a", { href: "https://docs.turbowarp.org/" }, c.a.createElement(u.a, { defaultMessage: "Documentation", id: "tw.footer.documentation" }))
                        ),
                        c.a.createElement(
                            "div",
                            { className: Oe.a.footerSection },
                            c.a.createElement("a", { href: "https://scratch.mit.edu/users/GarboMuffin/#comments" }, c.a.createElement(u.a, { defaultMessage: "Feedback & Bugs", id: "tw.feedback" })),
                            c.a.createElement("a", { href: "https://github.com/TurboWarp/" }, c.a.createElement(u.a, { defaultMessage: "Source Code", id: "tw.code" })),
                            c.a.createElement("a", { href: "privacy.html" }, c.a.createElement(u.a, { defaultMessage: "Privacy Policy", id: "tw.privacy" }))
                        )
                    )
                )
            );
        class Re extends c.a.Component {
            constructor(e) {
                super(e), (this.handleUpdateProjectTitle = this.handleUpdateProjectTitle.bind(this));
            }
            componentDidUpdate(e) {
                e.isLoading && !this.props.isLoading && "serviceWorker" in navigator && !je && ((je = !0), "complete" === document.readyState ? ke() : window.addEventListener("load", ke));
            }
            handleUpdateProjectTitle(e, t) {
                document.title = t || !e ? "OASIS Twarp" : "".concat(e, " - TurboWarp");
            }
            render() {
                const e = this.props,
                    { intl: t, hasCloudVariables: n, description: o, isFullScreen: a, isLoading: i, isPlayerOnly: s, isRtl: d, onClickTheme: l, projectId: p } = e,
                    h = Se(e, Pe),
                    f = s && !a,
                    b = !s;
                return c.a.createElement(
                    "div",
                    { className: r()(Oe.a.container, { [Oe.a.playerOnly]: f, [Oe.a.editor]: b }) },
                    f ? c.a.createElement("div", { className: Oe.a.menu }, c.a.createElement(Ae, { canChangeLanguage: !0, canManageFiles: !0, enableSeeInside: !0, onClickAddonSettings: Te, onClickTheme: l })) : null,
                    c.a.createElement(
                        "div",
                        { className: Oe.a.center, style: s ? { width: "".concat(Math.max(480, h.customStageSize.width) + 2, "px") } : null },
                        null,
                        c.a.createElement(L.a, Ce({ onClickAddonSettings: Te, onClickTheme: l, onUpdateProjectTitle: this.handleUpdateProjectTitle, backpackVisible: !0, backpackHost: "_local_" }, h)),
                        f
                            ? c.a.createElement(
                                  c.a.Fragment,
                                  null,
                                  Object(ge.c)() ? null : c.a.createElement(ue.a, { isRtl: d }),
                                  Object(ge.b)() ? null : c.a.createElement(pe.a, { isRtl: d }),
                                  c.a.createElement("div", { className: Oe.a.section }, c.a.createElement(z, null)),
                                  ("unshared" === o.instructions || "unshared" === o.credits) &&
                                      c.a.createElement(
                                          "div",
                                          { className: Oe.a.unsharedUpdate },
                                          c.a.createElement("p", null, c.a.createElement(u.a, { defaultMessage: "Unshared projects are no longer visible.", id: "tw.unshared2.1" })),
                                          c.a.createElement(
                                              "p",
                                              null,
                                              c.a.createElement(u.a, {
                                                  defaultMessage: "For more information, visit: {link}",
                                                  id: "tw.unshared.2",
                                                  values: {
                                                      link: c.a.createElement("a", { href: "https://docs.turbowarp.org/unshared-projects", target: "_blank", rel: "noopener noreferrer" }, "https://docs.turbowarp.org/unshared-projects"),
                                                  },
                                              })
                                          ),
                                          c.a.createElement("p", null, c.a.createElement(u.a, { defaultMessage: "If the project was shared recently, this message may appear incorrectly for a few minutes.", id: "tw.unshared.cache" })),
                                          c.a.createElement("p", null, c.a.createElement(u.a, { defaultMessage: "If this project is actually shared, please report a bug.", id: "tw.unshared.bug" }))
                                      ),
                                  n && "0" !== p && c.a.createElement("div", { className: Oe.a.section }, c.a.createElement(ve, null)),
                                  o.instructions || o.credits ? c.a.createElement("div", { className: Oe.a.section }, c.a.createElement(le, { instructions: o.instructions, credits: o.credits, projectId: p })) : null,
                                  c.a.createElement(
                                      "div",
                                      { className: Oe.a.section },
                                      c.a.createElement(
                                          "p",
                                          null,
                                          c.a.createElement(u.a, {
                                              defaultMessage:
                                                  "TurboWarp is a Scratch mod that compiles projects to JavaScript to make them run really fast. Try it out by inputting a project ID or URL above or choosing a featured project below.",
                                              id: "tw.home.description",
                                          })
                                      )
                                  ),
                                  c.a.createElement("div", { className: Oe.a.section }, c.a.createElement(oe, { studio: "27205657" }))
                              )
                            : null
                    ),
                    f && c.a.createElement(Ne, null)
                );
            }
        }
        Re.propTypes = {
            intl: u.f,
            hasCloudVariables: i.a.bool,
            customStageSize: i.a.shape({ width: i.a.number, height: i.a.number }),
            description: i.a.shape({ credits: i.a.string, instructions: i.a.string }),
            isFullScreen: i.a.bool,
            isLoading: i.a.bool,
            isPlayerOnly: i.a.bool,
            isRtl: i.a.bool,
            onClickTheme: i.a.func,
            projectId: i.a.string,
        };
        const Fe = Object(u.e)(
                Object(d.b)(
                    (e) => ({
                        hasCloudVariables: e.scratchGui.tw.hasCloudVariables,
                        customStageSize: e.scratchGui.customStageSize,
                        description: e.scratchGui.tw.description,
                        isFullScreen: e.scratchGui.mode.isFullScreen,
                        isLoading: Object(p.m)(e.scratchGui.projectState.loadingState),
                        isPlayerOnly: e.scratchGui.mode.isPlayerOnly,
                        isRtl: e.locales.isRtl,
                        projectId: e.scratchGui.projectState.projectId,
                    }),
                    () => ({})
                )(Re)
            ),
            Me = Object(l.d)(
                h.a,
                Object(f.a)("TW Interface"),
                b.a,
                m.a,
                v.a,
                function (e) {
                    class t extends c.a.Component {
                        constructor(e) {
                            super(e), P()(this, ["createRestorePoint"]), (this.timeout = null);
                        }
                        componentDidUpdate(e) {
                            N ||
                                (this.props.projectChanged === e.projectChanged && this.props.isShowingProject === e.isShowingProject) ||
                                (this.props.projectChanged && this.props.isShowingProject ? (this.timeout = setTimeout(this.createRestorePoint, 3e5)) : (clearTimeout(this.timeout), (this.timeout = null)));
                        }
                        componentWillUnmount() {
                            clearTimeout(this.timeout);
                        }
                        async createRestorePoint() {
                            try {
                                this.props.onAutosavingStart(), await T.a.save(this.props.vm);
                            } catch (e) {
                                N = !0;
                            }
                            (this.timeout = null),
                                setTimeout(() => {
                                    this.props.onAutosavingFinish(), null === this.timeout && !N && this.props.projectChanged && this.props.isShowingProject && (this.timeout = setTimeout(this.createRestorePoint, 3e5));
                                }, 250);
                        }
                        render() {
                            const t = this.props,
                                { projectChanged: n, onAutosavingStart: o, onAutosavingFinish: r, vm: a } = t,
                                i = A(t, I);
                            return c.a.createElement(e, i);
                        }
                    }
                    t.propTypes = { isShowingProject: i.a.bool, projectChanged: i.a.bool, onAutosavingStart: i.a.func, onAutosavingFinish: i.a.func, vm: i.a.instanceOf(S.a) };
                    return Object(d.b)(
                        (e) => ({ isShowingProject: Object(p.r)(e.scratchGui.projectState.loadingState), projectChanged: e.scratchGui.projectChanged, vm: e.scratchGui.vm }),
                        (e) => ({ onAutosavingStart: () => e(Object(E.i)("twAutosaving")), onAutosavingFinish: () => e(Object(E.c)("twAutosaving")) })
                    )(t);
                },
                x
            )(Fe);
        t.a = Me;
    },
    17: function (e, t, n) {
        var o = n(271);
        "string" == typeof o && (o = [[e.i, o, ""]]);
        var r = { hmr: !0, transform: void 0, insertInto: void 0 };
        n(10)(o, r);
        o.locals && (e.exports = o.locals);
    },
    247: function (e, t, n) {
        (t = e.exports = n(9)(!1)).push([
            e.i,
            '/* #E5F0FF */ /* #E9F1FC */ /* #D9E3F2 */ /* 90% transparent version of motion-primary */ /* #FFFFFF */ /* 25% transparent version of ui-white */ /* 25% transparent version of ui-white */ /* 25% transparent version of ui-white */ /* 15% transparent version of black */ /* #575E75 */ /* 35% transparent version of motion-primary */ /* 15% transparent version of motion-primary */ /* opt-in theme overrides */ /* #FF661A */ /* #E64D00 */ /* #CF63CF */ /* #BD42BD */ /* #FFAB19 */ /* #FF8C1A */ /* #0FBD8C */ /* #0FBD8C */ /* #FF8C1A */ /* #FFB366 */ /* #FF8C1A */ /* 35% transparent version of extensions-primary */ /* opaque version of extensions-transparent, on white bg */ /* lighter than motion-primary */ /*\n    Contains constants for the z-index values of elements that are part of the global stack context.\n    In other words, z-index values that are "inside" a component are not added here.\n    This prevents conflicts between identical z-index values in different components.\n*/ /* Toolbox z-index: 40; set in scratch-blocks */ /* tooltips should go over add buttons if they overlap */ /* monitors go over add buttons */ /* "ask" block text input goes above monitors */ /* menu-bar should go over monitors, alerts and tutorials */ /* tw: show below menu bar normally */ /* Block drag z-index: 1000; default 50 is overriden in blocks.css */ /* so it is draggable into other panes */ /* in most interfaces, the context menu is always on top */ .project-input_input_1E6Af {\n    border: none;\n    width: 100%;\n    font-size: 23px;\n    line-height: 32px;\n    opacity: 0.5;\n    background-color: transparent;\n    color: inherit;\n} .project-input_input_1E6Af:focus {\n    opacity: 1;\n} .project-input_input_1E6Af:disabled {\n    opacity: 0.8;\n} .project-input_tooltip_3_EoA {\n    opacity: 1 !important;\n    background-color: hsla(10, 85%, 65%, 1) !important;\n    border: 1px solid hsla(0, 0%, 0%, .1) !important;\n    box-shadow: 0 0 .5rem hsla(0, 0%, 0%, .25) !important;\n    font-family: "Helvetica Neue", Helvetica, Arial, sans-serif !important;\n    border: 1px solid hsla(0, 0%, 0%, .1) !important;\n    z-index: 491 !important;\n} .project-input_tooltip_3_EoA:after {\n    border-top-color: hsla(10, 85%, 65%, 1) !important;\n}\n',
            "",
        ]),
            (t.locals = { input: "project-input_input_1E6Af", tooltip: "project-input_tooltip_3_EoA" });
    },
    248: function (e, t, n) {
        (t = e.exports = n(9)(!1)).push([
            e.i,
            "/*\nImported from:\nhttps://github.com/forkphorus/forkphorus/tree/master/studioview\nWith changes to make it work properly in the scratch-gui environment.\n*/\n\n/* we wrap it in a <div> */\n\n.studioview_wrapper_1SFBd {\n  height: 100%;\n}\n\n/* fix some styles that can be messed up by scratch-gui */\n\n.studioview_studioview-root_1OP-i * {\n  box-sizing: content-box !important;\n}\n\n.studioview_studioview-root_1OP-i {\n  height: 100%;\n}\n\n.studioview_studioview-list_2hIxk {\n  width: 100%;\n  height: 100%;\n  overflow-y: scroll;\n  overflow-anchor: none;\n}\n\n.studioview_studioview-project_IDotv, .studioview_studioview-placeholder_KKHo9 {\n  display: inline-block;\n  width: 144px;\n  padding: 3px;\n  margin-bottom: 1px;\n  margin-right: 1px;\n}\n\n.studioview_studioview-root_1OP-i .studioview_studioview-project_IDotv {\n  color: inherit;\n  position: relative;\n  text-decoration: none;\n}\n\n.studioview_studioview-loaded_3UCil:hover::before, .studioview_studioview-loaded_3UCil:active::before {\n  content: '';\n  pointer-events: none;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n      -ms-user-select: none;\n          user-select: none;\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  background-color: currentColor;\n  opacity: 0.1;\n}\n\n.studioview_studioview-root_1OP-i .studioview_studioview-loaded_3UCil:active::before {\n  opacity: 0.2;\n}\n\n.studioview_studioview-root_1OP-i .studioview_studioview-title_2ROWB,\n.studioview_studioview-root_1OP-i .studioview_studioview-author_2P0Hj {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n  color: inherit;\n  text-decoration: none;\n}\n\n.studioview_studioview-title_2ROWB {\n  font-size: 0.8em;\n  font-weight: bold;\n}\n\n.studioview_studioview-author_2P0Hj {\n  font-size: 0.75em;\n}\n\n.studioview_studioview-error_3XWai {\n  width: 100%;\n}\n\n.studioview_studioview-thumbnail_1HYJO, .studioview_studioview-placeholder-thumbnail_TUdop {\n  position: relative;\n  width: 144px;\n  height: 108px;\n}\n\n.studioview_studioview-thumbnail_1HYJO::before {\n  content: '';\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  background-color: currentColor;\n  opacity: 0.1;\n}\n\n.studioview_studioview-thumbnail_1HYJO img {\n  width: 100%;\n  height: 100%;\n}\n\n.studioview_studioview-placeholder_KKHo9 .studioview_studioview-thumbnail_1HYJO,\n.studioview_studioview-placeholder_KKHo9 .studioview_studioview-title_2ROWB,\n.studioview_studioview-placeholder_KKHo9 .studioview_studioview-author_2P0Hj {\n  background-color: currentColor;\n  opacity: 0.1;\n}\n\n.studioview_studioview-title_2ROWB {\n  height: 20px;\n  margin-top: 2px;\n}\n\n.studioview_studioview-author_2P0Hj {\n  height: 18px;\n}\n\n.studioview_studioview-placeholder_KKHo9 .studioview_studioview-title_2ROWB {\n  border-radius: 2px 2px 2px 0;\n  width: 100%;\n}\n\n.studioview_studioview-placeholder_KKHo9 .studioview_studioview-author_2P0Hj {\n  border-radius: 0 0 2px 2px;\n  width: 50%;\n}\n",
            "",
        ]),
            (t.locals = {
                wrapper: "studioview_wrapper_1SFBd",
                "studioview-root": "studioview_studioview-root_1OP-i",
                studioviewRoot: "studioview_studioview-root_1OP-i",
                "studioview-list": "studioview_studioview-list_2hIxk",
                studioviewList: "studioview_studioview-list_2hIxk",
                "studioview-project": "studioview_studioview-project_IDotv",
                studioviewProject: "studioview_studioview-project_IDotv",
                "studioview-placeholder": "studioview_studioview-placeholder_KKHo9",
                studioviewPlaceholder: "studioview_studioview-placeholder_KKHo9",
                "studioview-loaded": "studioview_studioview-loaded_3UCil",
                studioviewLoaded: "studioview_studioview-loaded_3UCil",
                "studioview-title": "studioview_studioview-title_2ROWB",
                studioviewTitle: "studioview_studioview-title_2ROWB",
                "studioview-author": "studioview_studioview-author_2P0Hj",
                studioviewAuthor: "studioview_studioview-author_2P0Hj",
                "studioview-error": "studioview_studioview-error_3XWai",
                studioviewError: "studioview_studioview-error_3XWai",
                "studioview-thumbnail": "studioview_studioview-thumbnail_1HYJO",
                studioviewThumbnail: "studioview_studioview-thumbnail_1HYJO",
                "studioview-placeholder-thumbnail": "studioview_studioview-placeholder-thumbnail_TUdop",
                studioviewPlaceholderThumbnail: "studioview_studioview-placeholder-thumbnail_TUdop",
            });
    },
    249: function (e, t, n) {
        (t = e.exports = n(9)(!1)).push([
            e.i,
            ".featured-projects_container_1--ew {\n    margin-bottom: 8px;\n}\n\n.featured-projects_opener-container_1c9_H {\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    cursor: pointer;\n    -webkit-user-select: none;\n       -moz-user-select: none;\n        -ms-user-select: none;\n            user-select: none;\n    opacity: 0.8;\n    color: #222;\n}\n\n.featured-projects_opener-container_1c9_H:hover {\n    opacity: 1;\n}\n\n.featured-projects_opener-content_1kqev {\n    background-color: white;\n    padding: 4px;\n    border: 1px solid black;\n    box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.25);\n}\n\n.featured-projects_projects_1piAv {\n    position: relative;\n    height: 155px;\n}\n\n.featured-projects_projects_1piAv.featured-projects_transition_3TsdC {\n    transition: .2s height;\n}\n\n.featured-projects_projects_1piAv.featured-projects_opened_eLMQu {\n    height: 310px;\n}\n\n.featured-projects_footer_2fw_5 {\n    \n}\n",
            "",
        ]),
            (t.locals = {
                container: "featured-projects_container_1--ew",
                "opener-container": "featured-projects_opener-container_1c9_H",
                openerContainer: "featured-projects_opener-container_1c9_H",
                "opener-content": "featured-projects_opener-content_1kqev",
                openerContent: "featured-projects_opener-content_1kqev",
                projects: "featured-projects_projects_1piAv",
                transition: "featured-projects_transition_3TsdC",
                opened: "featured-projects_opened_eLMQu",
                footer: "featured-projects_footer_2fw_5",
            });
    },
    25: function (e, t, n) {
        var o = n(248);
        "string" == typeof o && (o = [[e.i, o, ""]]);
        var r = { hmr: !0, transform: void 0, insertInto: void 0 };
        n(10)(o, r);
        o.locals && (e.exports = o.locals);
    },
    250: function (e, t, n) {
        (t = e.exports = n(9)(!1)).push([
            e.i,
            '.description_description_1iyDJ {\n    max-height: 250px;\n    overflow: auto;\n    white-space: pre-line;\n    overflow-wrap: break-word;\n    line-height: 1.5em;\n    padding: 0.5rem;\n    margin: 5px 0 8px 0;\n    border: 1px solid #b9d6ff;\n    background-color: #dbebff;\n    border-radius: 0.5rem;\n}\n\n.description_description_1iyDJ a {\n    font-weight: bold;\n    text-decoration: none;\n}\n\n[theme="dark"] .description_description_1iyDJ {\n    border-color: #203652;\n    background-color: #16202c;\n}\n\n.description_header_27V8b {\n    font-weight: bold;\n    font-size: 1em;\n    margin: 0;\n    padding: 0;\n}\n\n.description_divider_3z5W7 {\n    margin-top: 8px;\n}\n\n.description_project-link_2-Z1r {\n    margin-bottom: 2px;\n}\n',
            "",
        ]),
            (t.locals = {
                description: "description_description_1iyDJ",
                header: "description_header_27V8b",
                divider: "description_divider_3z5W7",
                "project-link": "description_project-link_2-Z1r",
                projectLink: "description_project-link_2-Z1r",
            });
    },
    251: function (e, t, n) {
        var o = n(252),
            r = n(256),
            a = n(257),
            i = a && a.isRegExp,
            s = i ? r(i) : o;
        e.exports = s;
    },
    252: function (e, t, n) {
        var o = n(86),
            r = n(70);
        e.exports = function (e) {
            return r(e) && "[object RegExp]" == o(e);
        };
    },
    253: function (e, t, n) {
        var o = n(152),
            r = "object" == typeof self && self && self.Object === Object && self,
            a = o || r || Function("return this")();
        e.exports = a;
    },
    254: function (e, t, n) {
        var o = n(87),
            r = Object.prototype,
            a = r.hasOwnProperty,
            i = r.toString,
            s = o ? o.toStringTag : void 0;
        e.exports = function (e) {
            var t = a.call(e, s),
                n = e[s];
            try {
                e[s] = void 0;
                var o = !0;
            } catch (e) {}
            var r = i.call(e);
            return o && (t ? (e[s] = n) : delete e[s]), r;
        };
    },
    255: function (e, t) {
        var n = Object.prototype.toString;
        e.exports = function (e) {
            return n.call(e);
        };
    },
    256: function (e, t) {
        e.exports = function (e) {
            return function (t) {
                return e(t);
            };
        };
    },
    257: function (e, t, n) {
        (function (e) {
            var o = n(152),
                r = t && !t.nodeType && t,
                a = r && "object" == typeof e && e && !e.nodeType && e,
                i = a && a.exports === r && o.process,
                s = (function () {
                    try {
                        var e = a && a.require && a.require("util").types;
                        return e || (i && i.binding && i.binding("util"));
                    } catch (e) {}
                })();
            e.exports = s;
        }.call(this, n(206)(e)));
    },
    258: function (e, t, n) {
        var o = n(259),
            r = /[\\^$.*+?()[\]{}|]/g,
            a = RegExp(r.source);
        e.exports = function (e) {
            return (e = o(e)) && a.test(e) ? e.replace(r, "\\$&") : e;
        };
    },
    259: function (e, t, n) {
        var o = n(260);
        e.exports = function (e) {
            return null == e ? "" : o(e);
        };
    },
    260: function (e, t, n) {
        var o = n(87),
            r = n(261),
            a = n(112),
            i = n(262),
            s = o ? o.prototype : void 0,
            c = s ? s.toString : void 0;
        e.exports = function e(t) {
            if ("string" == typeof t) return t;
            if (a(t)) return r(t, e) + "";
            if (i(t)) return c ? c.call(t) : "";
            var n = t + "";
            return "0" == n && 1 / t == -1 / 0 ? "-0" : n;
        };
    },
    261: function (e, t) {
        e.exports = function (e, t) {
            for (var n = -1, o = null == e ? 0 : e.length, r = Array(o); ++n < o; ) r[n] = t(e[n], n, e);
            return r;
        };
    },
    262: function (e, t, n) {
        var o = n(86),
            r = n(70);
        e.exports = function (e) {
            return "symbol" == typeof e || (r(e) && "[object Symbol]" == o(e));
        };
    },
    263: function (e, t, n) {
        var o = n(86),
            r = n(112),
            a = n(70);
        e.exports = function (e) {
            return "string" == typeof e || (!r(e) && a(e) && "[object String]" == o(e));
        };
    },
    264: function (e, t, n) {
        var o = n(265);
        e.exports = function (e) {
            return (null == e ? 0 : e.length) ? o(e, 1) : [];
        };
    },
    265: function (e, t, n) {
        var o = n(266),
            r = n(267);
        e.exports = function e(t, n, a, i, s) {
            var c = -1,
                d = t.length;
            for (a || (a = r), s || (s = []); ++c < d; ) {
                var l = t[c];
                n > 0 && a(l) ? (n > 1 ? e(l, n - 1, a, i, s) : o(s, l)) : i || (s[s.length] = l);
            }
            return s;
        };
    },
    266: function (e, t) {
        e.exports = function (e, t) {
            for (var n = -1, o = t.length, r = e.length; ++n < o; ) e[r + n] = t[n];
            return e;
        };
    },
    267: function (e, t, n) {
        var o = n(87),
            r = n(268),
            a = n(112),
            i = o ? o.isConcatSpreadable : void 0;
        e.exports = function (e) {
            return a(e) || r(e) || !!(i && e && e[i]);
        };
    },
    268: function (e, t, n) {
        var o = n(269),
            r = n(70),
            a = Object.prototype,
            i = a.hasOwnProperty,
            s = a.propertyIsEnumerable,
            c = o(
                (function () {
                    return arguments;
                })()
            )
                ? o
                : function (e) {
                      return r(e) && i.call(e, "callee") && !s.call(e, "callee");
                  };
        e.exports = c;
    },
    269: function (e, t, n) {
        var o = n(86),
            r = n(70);
        e.exports = function (e) {
            return r(e) && "[object Arguments]" == o(e);
        };
    },
    270: function (e, t, n) {
        (t = e.exports = n(9)(!1)).push([
            e.i,
            '.cloud-variable-badge_badge_2kZVK {\n    padding: 0.5rem;\n    margin: 5px 0 8px 0;\n    border: 1px solid #b9d6ff;\n    background-color: #dbebff;\n    display: flex;\n    align-items: center;\n    border-radius: 0.5rem;\n}\n[theme="dark"] .cloud-variable-badge_badge_2kZVK {\n    border-color: #203652;\n    background-color: #16202c;\n}\n.cloud-variable-badge_icon_3PN9C {\n    margin-right: 0.25rem;\n}\n[theme="dark"] .cloud-variable-badge_icon_3PN9C {\n    filter: invert(100%);\n}\n.cloud-variable-badge_text_1V3lA {\n\n}\n',
            "",
        ]),
            (t.locals = { badge: "cloud-variable-badge_badge_2kZVK", icon: "cloud-variable-badge_icon_3PN9C", text: "cloud-variable-badge_text_1V3lA" });
    },
    271: function (e, t, n) {
        (t = e.exports = n(9)(!1)).push([
            e.i,
            '/* Base styles used by Scratch https://github.com/LLK/scratch-www/blob/develop/src/main.scss */\nh1,\nh2,\nh3,\nh4,\nh5,\np {\n    margin: 0;\n    padding: 0;\n    border: 0;\n}\nh1,\nh2,\nh3,\nh4,\nh5 {\n    font-weight: bold;\n    line-height: 1.7em;\n}\nh1 {\n    font-weight: 2.5rem;\n}\nh2 {\n    font-weight: 2rem;\n}\nh3 {\n    font-size: 1.4rem;\n}\nh4 {\n    font-size: 1rem;\n}\na {\n    color: #25d;\n    cursor: pointer;\n    text-decoration: underline;\n}\n.interface_container_2nBns {\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n}\n.interface_editor_3jGyG {\n    min-width: 1024px;\n    min-height: 640px;\n    height: 100%;\n}\n.interface_editor_3jGyG .interface_center_2d9_b {\n    height: 100%;\n}\n.interface_player-only_38SyA .interface_center_2d9_b {\n    margin: auto;\n}\n.interface_menu_3K-Q2 {\n    margin-bottom: 8px;\n}\n.interface_section_3pFkT {\n    margin: 8px 0 8px 0;\n}\n.interface_footer_3JeCN {\n    padding: 10px 0;\n    margin-top: 10px;\n    border-top: 2px solid #ddd;\n}\n.interface_footer_3JeCN a {\n    font-weight: bold;\n    text-decoration: none;\n}\n[theme="dark"] .interface_footer_3JeCN {\n    border-color: #1a1a1a;\n}\n.interface_footer-content_1aIC- {\n    max-width: 600px;\n    margin: auto;\n}\n.interface_footer-text_IgwDU {\n    text-align: center;\n    margin: 5px 0 10px 0;\n}\n.interface_footer-columns_1SUSg {\n    display: flex;\n    justify-content: center;\n    justify-items: center;\n    flex-wrap: wrap;\n}\n.interface_footer-section_11lCO {\n    display: flex;\n    flex-direction: column;\n    width: 200px;\n    margin-bottom: 10px;\n}\n.interface_footer-section_11lCO > * {\n    margin-bottom: 10px;\n}\n[theme="dark"] .interface_container_2nBns {\n    background-color: #111;\n}\n[theme="dark"] .interface_player-only_38SyA {\n    color: #ddd;\n}\n[theme="dark"] a {\n    color: #4af;\n}\n.interface_unshared-update_i7deb {\n    line-height: 1.5em;\n    padding: 0.5rem;\n    margin: 5px 0 8px 0;\n    border: 1px solid #ffb9b9;\n    background-color: #ffdbdb;\n    border-radius: 0.5rem;\n}\n[theme="dark"] .interface_unshared-update_i7deb {\n    border-color: #6a2929;\n    background-color: #452222;\n}\n.interface_unshared-update_i7deb p {\n    margin: 4px 0;\n}\n.interface_unshared-update_i7deb a {\n    font-weight: bold;\n    text-decoration: none;\n}\n',
            "",
        ]),
            (t.locals = {
                container: "interface_container_2nBns",
                editor: "interface_editor_3jGyG",
                center: "interface_center_2d9_b",
                "player-only": "interface_player-only_38SyA",
                playerOnly: "interface_player-only_38SyA",
                menu: "interface_menu_3K-Q2",
                section: "interface_section_3pFkT",
                footer: "interface_footer_3JeCN",
                "footer-content": "interface_footer-content_1aIC-",
                footerContent: "interface_footer-content_1aIC-",
                "footer-text": "interface_footer-text_IgwDU",
                footerText: "interface_footer-text_IgwDU",
                "footer-columns": "interface_footer-columns_1SUSg",
                footerColumns: "interface_footer-columns_1SUSg",
                "footer-section": "interface_footer-section_11lCO",
                footerSection: "interface_footer-section_11lCO",
                "unshared-update": "interface_unshared-update_i7deb",
                unsharedUpdate: "interface_unshared-update_i7deb",
            });
    },
    46: function (e, t, n) {
        var o = n(249);
        "string" == typeof o && (o = [[e.i, o, ""]]);
        var r = { hmr: !0, transform: void 0, insertInto: void 0 };
        n(10)(o, r);
        o.locals && (e.exports = o.locals);
    },
    48: function (e, t, n) {
        "use strict";
        let o, r;
        "undefined" != typeof BroadcastChannel && ((o = new BroadcastChannel("addons-change")), (r = new BroadcastChannel("addons-reload"))), (t.a = { changeChannel: o, reloadChannel: r });
    },
    59: function (e, t, n) {
        var o = n(250);
        "string" == typeof o && (o = [[e.i, o, ""]]);
        var r = { hmr: !0, transform: void 0, insertInto: void 0 };
        n(10)(o, r);
        o.locals && (e.exports = o.locals);
    },
    70: function (e, t) {
        e.exports = function (e) {
            return null != e && "object" == typeof e;
        };
    },
    86: function (e, t, n) {
        var o = n(87),
            r = n(254),
            a = n(255),
            i = o ? o.toStringTag : void 0;
        e.exports = function (e) {
            return null == e ? (void 0 === e ? "[object Undefined]" : "[object Null]") : i && i in Object(e) ? r(e) : a(e);
        };
    },
    868: function (e, t, n) {
        "use strict";
        n.r(t);
        n(292);
        var o = n(51),
            r = n.n(o),
            a = n(1),
            i = n.n(a),
            s = n(64),
            c = n(155),
            d = n(67);
        Object(s.setAppElement)(d.a), r.a.render(i.a.createElement(c.a, null), d.a);
    },
    87: function (e, t, n) {
        var o = n(253).Symbol;
        e.exports = o;
    },
    88: function (e, t, n) {
        "use strict";
        n.d(t, "b", function () {
            return d;
        }),
            n.d(t, "a", function () {
                return u;
            });
        var o = n(1),
            r = n.n(o),
            a = n(89),
            i = n.n(a);
        function s() {
            return (s =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
                    }
                    return e;
                }).apply(this, arguments);
        }
        const c = window.matchMedia("(prefers-color-scheme: dark)"),
            d = () => {
                try {
                    const e = localStorage.getItem("tw:theme");
                    if (null !== e) return "dark" === e;
                } catch (e) {}
                return c.matches;
            },
            l = document.createElement("style");
        l.textContent = i.a;
        const u = function (e) {
            class t extends r.a.Component {
                constructor(e) {
                    super(e), (this.handleQueryChange = this.handleQueryChange.bind(this)), (this.handleClickTheme = this.handleClickTheme.bind(this)), (this.state = { dark: d() });
                }
                componentDidMount() {
                    c.addEventListener && c.addEventListener("change", this.handleQueryChange), this.updateDark();
                }
                componentDidUpdate() {
                    try {
                        localStorage.setItem("tw:theme", this.state.dark ? "dark" : "light");
                    } catch (e) {}
                    this.updateDark();
                }
                componentWillUnmount() {
                    c.removeEventListener && c.removeEventListener("change", this.handleQueryChange);
                }
                updateDark() {
                    const e = this.state.dark;
                    document.body.setAttribute("theme", e ? "dark" : "light"), e && !l.parentNode ? document.body.insertBefore(l, document.body.firstChild) : !e && l.parentNode && l.parentNode.removeChild(l);
                }
                handleQueryChange() {
                    this.setState({ dark: c.matches });
                }
                handleClickTheme() {
                    this.setState((e) => ({ dark: !e.dark }));
                }
                render() {
                    return r.a.createElement(e, s({ onClickTheme: this.handleClickTheme, isDark: this.state.dark }, this.props));
                }
            }
            return t;
        };
    },
    89: function (e, t) {
        e.exports =
            '/* GUI */\n:root {\n    background: #111;\n    color: #eee;\n    color-scheme: dark;\n    /* see colors.csss */\n    --ui-primary: rgb(17, 17, 17);\n    --ui-secondary: rgb(30, 30, 30);\n    --ui-tertiary: rgb(46, 46, 46);\n    --ui-modal-overlay: #333a;\n    --ui-black-transparent: rgba(255, 255, 255, 0.15);\n    --text-primary: #eee;\n    /* scratch-paint */\n    --paint-ui-pane-border: var(--ui-black-transparent);\n    --paint-text-primary: #eee;\n    --paint-form-border: var(--ui-black-transparent);\n}\n\n/* Blockly */\n.blocklySvg {\n    background-color: var(--ui-secondary) !important;\n    color-scheme: light;\n}\n[id^="blocklyGridPattern"] > line {\n    stroke: #484848;\n}\n.blocklyFlyoutBackground {\n    fill: #111;\n}\n.blocklyFlyoutLabelText {\n    fill: #ccc;\n}\n.blocklyFlyoutButton .blocklyText {\n    fill: #ccc;\n}\n.blocklyFlyoutButton:hover {\n    fill: #111;\n}\n/* blocklyFlyoutCheckboxPath stroke and blocklyFlyoutCheckbox fill must match */\n.blocklyFlyoutCheckboxPath {\n    stroke: #111;\n}\n.blocklyFlyoutCheckbox {\n    fill: #111;\n}\n.checked > .blocklyFlyoutCheckbox {\n    stroke: #a1c6fa;\n}\n.checked > .blocklyFlyoutCheckboxPath {\n    stroke: white;\n}\n.scratchCategoryMenu {\n    color: #ccc;\n}\n.blocklyToolboxDiv,\n.scratchCategoryMenu {\n    background: #111 !important;\n}\n.blocklyScrollbarHandle {\n    fill: #666;\n}\n.blocklyZoom {\n    filter: invert(100%);\n}\n.scratchCategoryMenuItem.categorySelected {\n    background: var(--ui-secondary);\n}\n.valueReportBox {\n    color: black;\n}\n.blocklyWidgetDiv {\n    color-scheme: light;\n}\n.blocklyWidgetDiv .goog-menu {\n    background: var(--ui-primary);\n    border-color: var(--ui-black-transparent);\n}\n.blocklyWidgetDiv .goog-menuitem {\n    color: var(--text-primary);\n}\n.blocklyWidgetDiv .goog-menuitem-disabled .goog-menuitem-content {\n    color: #666 !important;\n}\n.sa-blockly-menu-item-border {\n    border-top-color: var(--ui-black-transparent) !important;\n}\n.blocklyWidgetDiv .goog-menuitem.goog-menuitem-highlight {\n    background-color: var(--ui-tertiary);\n    border-color: transparent; /* remove border */\n}\n.scratchCommentText {\n    color: black;\n}\n.blocklyInsertionMarker > .blocklyPath {\n    fill: #ccc;\n}\n\n/* Other / Multipurpose */\n.Popover {\n    /* weird Chrome bug displays white bar above popovers with color-scheme: dark */\n    color-scheme: light;\n}\n.Popover-body {\n    background: var(--ui-secondary);\n    border-color: var(--ui-black-transparent);\n    color: var(--text-primary);\n}\n.Popover-tipShape {\n    fill: var(--ui-secondary);\n    stroke: var(--ui-black-transparent);\n}\n';
    },
    95: function (e, t, n) {
        var o = n(251),
            r = n(258),
            a = n(263),
            i = n(264);
        e.exports = function (e, t, n) {
            return (
                Array.isArray(e) || (e = [e]),
                i(
                    e.map(function (e) {
                        return a(e)
                            ? (function (e, t, n) {
                                  var i = 0,
                                      s = 0;
                                  if ("" === e) return e;
                                  if (!e || !a(e)) throw new TypeError("First argument to react-string-replace#replaceString must be a string");
                                  var c = t;
                                  o(c) || (c = new RegExp("(" + r(c) + ")", "gi"));
                                  for (var d = e.split(c), l = 1, u = d.length; l < u; l += 2) (s = d[l].length), (i += d[l - 1].length), (d[l] = n(d[l], l, i)), (i += s);
                                  return d;
                              })(e, t, n)
                            : e;
                    })
                )
            );
        };
    },
    96: function (e, t, n) {
        var o = n(270);
        "string" == typeof o && (o = [[e.i, o, ""]]);
        var r = { hmr: !0, transform: void 0, insertInto: void 0 };
        n(10)(o, r);
        o.locals && (e.exports = o.locals);
    },
});
//# sourceMappingURL=editor.b28b67ee5e152489802f.js.map
